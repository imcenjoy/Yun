<p>{!! trans('user.verification.mail.message', ['sitename' => option_localized('site_name')]) !!}</p>
<p>{!! trans('user.verification.mail.reset', ['url' => $url]) !!}</p>
<p>{!! trans('user.verification.mail.ignore') !!}</p>
